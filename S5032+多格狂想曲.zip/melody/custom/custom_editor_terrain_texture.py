# -*- encoding:utf-8 -*-
_reload_all = True


data = {134229963: {'key': 134229963, 'describe': '', 'name': u'\u9ed1\u8272_color', 'uid': '134229963', 'size': '2048X1024', 'tex_id': 134229963}}