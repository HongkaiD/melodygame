# -*- encoding:utf-8 -*-
_reload_all = True


data = {134268657: {'path': u'134268657.ttf', 'describe': '', 'name': u'pixelfont', 'key': 134268657, 'engine_index_name': '134268657', 'uid': 'editor_font_134268657', 'is_custom': True}}