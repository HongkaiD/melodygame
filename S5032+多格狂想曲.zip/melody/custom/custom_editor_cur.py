# -*- encoding:utf-8 -*-
_reload_all = True

data = {}